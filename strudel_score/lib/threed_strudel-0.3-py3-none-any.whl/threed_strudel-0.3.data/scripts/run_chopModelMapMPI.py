#!python

from threed_strudel.chop import chopModelMapMPI


if __name__ == '__main__':
    chopModelMapMPI.main()