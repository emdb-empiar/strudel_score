#!python

from threed_strudel.average import mapAveraging


if __name__ == '__main__':
    mapAveraging.main()