#!python

from threed_strudel.validation import mapMotifValidation


if __name__ == '__main__':
    mapMotifValidation.main()