#!python

from threed_strudel.classify import penultimateClassifier


if __name__ == '__main__':
    penultimateClassifier.main()